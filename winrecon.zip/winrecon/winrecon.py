#!/usr/bin/env python3
"""
WinRecon | Python Windows Auditing Toolkit
Author: Jude Hilgendorf
GitHub: github.com/TiltedLunar123

Audits Windows systems for security misconfigurations,
user accounts, network settings, and more.
"""

import subprocess
import os
import sys
import ctypes
import json
import socket
import datetime
import platform
import re
from pathlib import Path


# ──────────────────────────────────────────────
# ANSI COLOR CODES & FORMATTING
# ──────────────────────────────────────────────

class Colors:
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    RESET   = "\033[0m"

C = Colors

BANNER = rf"""
{C.CYAN}{C.BOLD}
 __        __ _         ____                        
 \ \      / /(_) _ __  |  _ \  ___  ___  ___  _ __  
  \ \ /\ / / | || '_ \ | |_) |/ _ \/ __|/ _ \| '_ \ 
   \ V  V /  | || | | ||  _ <|  __/ (__| (_) | | | |
    \_/\_/   |_||_| |_||_| \_\\___|\___|\___/|_| |_|
{C.RESET}
{C.DIM}  Python Windows Auditing Toolkit
  Author : Jude Hilgendorf
  GitHub : github.com/TiltedLunar123{C.RESET}
"""

DIVIDER      = f"{C.BLUE}{'═' * 70}{C.RESET}"
DIVIDER_THIN = f"{C.BLUE}{'─' * 70}{C.RESET}"


# ──────────────────────────────────────────────
# UTILITY HELPERS
# ──────────────────────────────────────────────

def is_admin() -> bool:
    """Check if script is running with administrator privileges."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except AttributeError:
        return False


def enable_ansi():
    """Enable ANSI escape codes on Windows 10+ terminals."""
    try:
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except Exception:
        pass


def run_cmd(command: str, timeout: int = 30) -> str:
    """Run a shell command and return stdout (empty string on failure)."""
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            shell=True,
            errors="replace",
        )
        return result.stdout.strip()
    except Exception:
        return ""


def run_powershell(ps_command: str, timeout: int = 30) -> str:
    """Run a PowerShell command and return stdout."""
    cmd = f'powershell -NoProfile -ExecutionPolicy Bypass -Command "{ps_command}"'
    return run_cmd(cmd, timeout)


def section_header(title: str):
    """Print a formatted section header."""
    print(f"\n{DIVIDER}")
    print(f"  {C.BOLD}{C.CYAN}[ {title} ]{C.RESET}")
    print(DIVIDER)


def sub_header(title: str):
    """Print a formatted sub‑section header."""
    print(f"\n  {C.BOLD}{C.MAGENTA}▸ {title}{C.RESET}")
    print(f"  {C.BLUE}{'─' * 50}{C.RESET}")


def info(label: str, value: str):
    """Print a key : value pair."""
    print(f"    {C.WHITE}{label:<30}{C.RESET}: {C.GREEN}{value}{C.RESET}")


def warn(label: str, value: str):
    """Print a warning‑level key : value pair."""
    print(f"    {C.YELLOW}[!] {label:<26}{C.RESET}: {C.YELLOW}{value}{C.RESET}")


def critical(label: str, value: str):
    """Print a critical‑level key : value pair."""
    print(f"    {C.RED}[!!] {label:<25}{C.RESET}: {C.RED}{value}{C.RESET}")


def ok(message: str):
    print(f"    {C.GREEN}[✓] {message}{C.RESET}")


def finding(message: str):
    print(f"    {C.YELLOW}[!] {message}{C.RESET}")


def crit_finding(message: str):
    print(f"    {C.RED}[!!] {message}{C.RESET}")


def bullet(message: str):
    print(f"      {C.DIM}• {message}{C.RESET}")


# ──────────────────────────────────────────────
# REPORT COLLECTOR  (stores findings for JSON)
# ──────────────────────────────────────────────

class ReportCollector:
    """Collects all audit data for optional JSON export."""

    def __init__(self):
        self.data: dict = {
            "meta": {
                "tool": "WinRecon",
                "author": "Jude Hilgendorf",
                "timestamp": datetime.datetime.now().isoformat(),
            },
            "sections": {},
        }
        self._findings: list[str] = []

    def add_section(self, name: str, content: dict):
        self.data["sections"][name] = content

    def add_finding(self, severity: str, message: str):
        self._findings.append({"severity": severity, "message": message})

    def finalize(self):
        self.data["findings_summary"] = self._findings

    def export_json(self, path: str):
        self.finalize()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2, default=str)


report = ReportCollector()


# ──────────────────────────────────────────────
# MODULE 1 : SYSTEM INFORMATION
# ──────────────────────────────────────────────

def audit_system_info():
    section_header("SYSTEM INFORMATION")

    hostname   = platform.node()
    os_name    = platform.platform()
    os_version = platform.version()
    arch       = platform.machine()
    proc       = platform.processor()
    boot_time  = run_powershell(
        "(Get-CimInstance Win32_OperatingSystem).LastBootUpTime"
    )
    domain     = run_cmd("echo %USERDOMAIN%")
    uptime     = run_powershell(
        "(New-TimeSpan -Start (Get-CimInstance Win32_OperatingSystem)"
        ".LastBootUpTime).ToString()"
    )
    product_id = run_powershell(
        "(Get-CimInstance Win32_OperatingSystem).SerialNumber"
    )
    bios_ver   = run_powershell(
        "(Get-CimInstance Win32_BIOS).SMBIOSBIOSVersion"
    )
    total_ram  = run_powershell(
        "[math]::Round((Get-CimInstance Win32_ComputerSystem)"
        ".TotalPhysicalMemory / 1GB, 2)"
    )

    info("Hostname",       hostname)
    info("OS",             os_name)
    info("Version",        os_version)
    info("Architecture",   arch)
    info("Processor",      proc)
    info("Domain / WG",    domain)
    info("Last Boot",      boot_time)
    info("Uptime",         uptime)
    info("BIOS Version",   bios_ver)
    info("Product ID",     product_id)
    info("Total RAM (GB)", total_ram)

    report.add_section("system_info", {
        "hostname": hostname, "os": os_name, "version": os_version,
        "architecture": arch, "processor": proc, "domain": domain,
        "last_boot": boot_time, "uptime": uptime, "bios": bios_ver,
        "product_id": product_id, "total_ram_gb": total_ram,
    })


# ──────────────────────────────────────────────
# MODULE 2 : USER & GROUP ENUMERATION
# ──────────────────────────────────────────────

def audit_users_groups():
    section_header("USER ACCOUNTS & GROUPS")

    # --- Current user ---
    sub_header("Current User Context")
    current_user = os.environ.get("USERNAME", "Unknown")
    user_domain  = os.environ.get("USERDOMAIN", "Unknown")
    info("Username", current_user)
    info("Domain",   user_domain)
    info("Admin",    str(is_admin()))

    # --- Local users ---
    sub_header("Local User Accounts")
    users_raw = run_powershell(
        "Get-LocalUser | Select-Object Name, Enabled, "
        "LastLogon, PasswordRequired, PasswordLastSet "
        "| Format-List"
    )
    user_blocks = [b.strip() for b in users_raw.split("\n\n") if b.strip()]
    user_list = []

    for block in user_blocks:
        entry: dict = {}
        for line in block.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                entry[k.strip()] = v.strip()
        if entry:
            user_list.append(entry)
            name    = entry.get("Name", "?")
            enabled = entry.get("Enabled", "?")
            pw_req  = entry.get("PasswordRequired", "?")
            last    = entry.get("LastLogon", "Never")
            tag = ""
            if enabled.lower() == "true" and pw_req.lower() == "false":
                tag = f"  {C.RED}← NO PASSWORD REQUIRED{C.RESET}"
                report.add_finding("CRITICAL",
                                   f"User '{name}' has no password required")
            info(name, f"Enabled={enabled}  PwReq={pw_req}  LastLogon={last}{tag}")

    # --- Local groups ---
    sub_header("Local Groups")
    groups = run_powershell("Get-LocalGroup | Select-Object -ExpandProperty Name")
    for g in groups.splitlines():
        g = g.strip()
        if g:
            bullet(g)

    # --- Administrators group members ---
    sub_header("Administrators Group Members")
    admins = run_powershell(
        "Get-LocalGroupMember -Group Administrators "
        "| Select-Object Name, ObjectClass | Format-Table -AutoSize"
    )
    if admins:
        for line in admins.splitlines():
            line = line.strip()
            if line and "----" not in line:
                bullet(line)
    else:
        bullet("Could not enumerate (may require elevation)")

    report.add_section("users_groups", {
        "current_user": current_user, "is_admin": is_admin(),
        "local_users": user_list, "admin_members": admins,
    })


# ──────────────────────────────────────────────
# MODULE 3 : PASSWORD POLICY
# ──────────────────────────────────────────────

def audit_password_policy():
    section_header("PASSWORD POLICY")

    raw = run_cmd("net accounts")
    policy: dict = {}
    if raw:
        for line in raw.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                k, v = k.strip(), v.strip()
                policy[k] = v
                info(k, v)
        # --- checks ---
        min_len = policy.get("Minimum password length", "0")
        try:
            if int(min_len) < 8:
                finding(f"Minimum password length is only {min_len} characters")
                report.add_finding("WARNING",
                                   f"Password min length = {min_len}")
        except ValueError:
            pass

        max_age = policy.get("Maximum password age (days)", "")
        if max_age.lower() == "unlimited":
            finding("Passwords never expire")
            report.add_finding("WARNING", "Passwords set to never expire")

        lockout = policy.get("Lockout threshold", "Never")
        if lockout.lower() == "never":
            finding("No account lockout threshold — brute force risk")
            report.add_finding("WARNING", "No account lockout threshold")
    else:
        warn("net accounts", "Command failed (run as admin)")

    report.add_section("password_policy", policy)


# ──────────────────────────────────────────────
# MODULE 4 : NETWORK CONFIGURATION
# ──────────────────────────────────────────────

def audit_network_config():
    section_header("NETWORK CONFIGURATION")

    # --- Interfaces ---
    sub_header("IP Configuration")
    ip_config = run_cmd("ipconfig /all")
    adapters: list[dict] = []
    current: dict = {}

    for line in ip_config.splitlines():
        line_s = line.strip()
        if line and not line.startswith(" ") and ":" in line:
            if current:
                adapters.append(current)
            current = {"adapter": line_s.rstrip(":")}
        elif ":" in line_s:
            k, v = line_s.split(":", 1)
            current[k.strip().rstrip(".")] = v.strip()

    if current:
        adapters.append(current)

    for a in adapters:
        name = a.get("adapter", "Unknown")
        ipv4 = a.get("IPv4 Address", a.get("Autoconfiguration IPv4 Address", "N/A"))
        mask = a.get("Subnet Mask", "N/A")
        gw   = a.get("Default Gateway", "N/A")
        dhcp = a.get("DHCP Enabled", "N/A")
        dns  = a.get("DNS Servers", "N/A")
        mac  = a.get("Physical Address", "N/A")
        if ipv4 != "N/A" or mac != "N/A":
            print()
            info("Adapter",    name)
            info("IPv4",       ipv4)
            info("Subnet",     mask)
            info("Gateway",    gw)
            info("DHCP",       dhcp)
            info("DNS",        dns)
            info("MAC",        mac)

    # --- DNS cache (top entries) ---
    sub_header("DNS Cache (last 20 entries)")
    dns_cache = run_cmd("ipconfig /displaydns")
    records = re.findall(r"Record Name\s+:\s+(.+)", dns_cache)
    seen: set = set()
    count = 0
    for r in records:
        r = r.strip()
        if r not in seen:
            seen.add(r)
            bullet(r)
            count += 1
            if count >= 20:
                break

    # --- ARP table ---
    sub_header("ARP Table")
    arp = run_cmd("arp -a")
    arp_entries = []
    for line in arp.splitlines():
        parts = line.split()
        if len(parts) >= 3 and re.match(r"\d+\.\d+\.\d+\.\d+", parts[0]):
            bullet(f"{parts[0]:<18} {parts[1]:<20} {parts[2]}")
            arp_entries.append({"ip": parts[0], "mac": parts[1], "type": parts[2]})

    # --- Routing table ---
    sub_header("Routing Table (IPv4)")
    routes = run_cmd("route print -4")
    printing = False
    for line in routes.splitlines():
        if "Network Destination" in line:
            printing = True
        if printing:
            if line.strip() == "" and printing:
                break
            bullet(line.strip())

    report.add_section("network", {
        "adapters": adapters,
        "dns_cache_sample": list(seen)[:20],
        "arp_entries": arp_entries,
    })


# ──────────────────────────────────────────────
# MODULE 5 : OPEN PORTS & CONNECTIONS
# ──────────────────────────────────────────────

def audit_open_ports():
    section_header("OPEN PORTS & ACTIVE CONNECTIONS")

    sub_header("Listening Ports")
    raw = run_cmd("netstat -ano")
    listeners: list[dict] = []
    established: list[dict] = []

    for line in raw.splitlines():
        parts = line.split()
        if len(parts) >= 5 and parts[0] in ("TCP", "UDP"):
            proto, local, foreign, state, pid = (
                parts[0], parts[1], parts[2],
                parts[3] if len(parts) == 5 else "",
                parts[-1],
            )
            entry = {
                "proto": proto, "local": local,
                "foreign": foreign, "state": state, "pid": pid,
            }
            if state == "LISTENING":
                listeners.append(entry)
            elif state == "ESTABLISHED":
                established.append(entry)

    # Resolve PID → process name
    pid_map: dict = {}
    tasklist = run_cmd("tasklist /FO CSV /NH")
    for line in tasklist.splitlines():
        parts = line.replace('"', '').split(",")
        if len(parts) >= 2:
            pid_map[parts[1].strip()] = parts[0].strip()

    for l in listeners:
        proc = pid_map.get(l["pid"], "?")
        bullet(f"{l['proto']:<5} {l['local']:<25} PID {l['pid']:<8} {proc}")

    sub_header(f"Established Connections ({len(established)})")
    for e in established[:30]:
        proc = pid_map.get(e["pid"], "?")
        bullet(f"{e['proto']:<5} {e['local']:<25} → {e['foreign']:<25} PID {e['pid']:<8} {proc}")

    if len(established) > 30:
        bullet(f"... and {len(established) - 30} more")

    # --- Well‑known risky ports ---
    risky_ports = {
        "21": "FTP", "23": "Telnet", "445": "SMB",
        "3389": "RDP", "5985": "WinRM", "5986": "WinRM-S",
        "1433": "MSSQL", "3306": "MySQL", "5432": "Postgres",
    }
    sub_header("Risky Port Check")
    found_risky = False
    for l in listeners:
        port = l["local"].rsplit(":", 1)[-1]
        if port in risky_ports:
            finding(f"Port {port} ({risky_ports[port]}) is LISTENING")
            report.add_finding("WARNING",
                               f"Port {port} ({risky_ports[port]}) listening")
            found_risky = True
    if not found_risky:
        ok("No commonly‑risky ports detected listening")

    report.add_section("network_connections", {
        "listening_count": len(listeners),
        "established_count": len(established),
        "listeners": listeners[:50],
        "established": established[:50],
    })


# ──────────────────────────────────────────────
# MODULE 6 : FIREWALL STATUS
# ──────────────────────────────────────────────

def audit_firewall():
    section_header("WINDOWS FIREWALL STATUS")

    profiles = ["Domain", "Private", "Public"]
    fw_data: dict = {}

    for p in profiles:
        raw = run_powershell(
            f"(Get-NetFirewallProfile -Name {p})"
            f" | Select-Object Name, Enabled, DefaultInboundAction,"
            f" DefaultOutboundAction, LogFileName | Format-List"
        )
        enabled_match = re.search(r"Enabled\s*:\s*(\S+)", raw)
        inbound_match = re.search(r"DefaultInboundAction\s*:\s*(\S+)", raw)
        outbound_match = re.search(r"DefaultOutboundAction\s*:\s*(\S+)", raw)
        log_match = re.search(r"LogFileName\s*:\s*(.+)", raw)

        enabled  = enabled_match.group(1)  if enabled_match  else "Unknown"
        inbound  = inbound_match.group(1)  if inbound_match  else "Unknown"
        outbound = outbound_match.group(1) if outbound_match else "Unknown"
        log_file = log_match.group(1).strip() if log_match else "N/A"

        color = C.GREEN if enabled.lower() == "true" else C.RED
        info(f"{p} Profile",
             f"{color}Enabled={enabled}{C.RESET}  "
             f"In={inbound}  Out={outbound}")

        if enabled.lower() != "true":
            crit_finding(f"{p} profile firewall is DISABLED")
            report.add_finding("CRITICAL", f"Firewall {p} profile disabled")

        if inbound.lower() == "allow":
            finding(f"{p} inbound default is ALLOW (should be Block)")
            report.add_finding("WARNING",
                               f"Firewall {p} inbound default = Allow")

        fw_data[p] = {
            "enabled": enabled, "inbound": inbound,
            "outbound": outbound, "log": log_file,
        }

    report.add_section("firewall", fw_data)


# ──────────────────────────────────────────────
# MODULE 7 : WINDOWS DEFENDER / AV STATUS
# ──────────────────────────────────────────────

def audit_defender():
    section_header("ANTIVIRUS / WINDOWS DEFENDER STATUS")

    raw = run_powershell(
        "Get-MpComputerStatus | Select-Object "
        "AntivirusEnabled, AntispywareEnabled, RealTimeProtectionEnabled, "
        "IoavProtectionEnabled, BehaviorMonitorEnabled, "
        "AntivirusSignatureLastUpdated, QuickScanEndTime "
        "| Format-List"
    )

    defender: dict = {}
    if raw:
        for line in raw.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                k, v = k.strip(), v.strip()
                defender[k] = v
                is_bool_false = v.lower() == "false"
                if is_bool_false:
                    critical(k, v)
                    report.add_finding("CRITICAL", f"Defender {k} = False")
                else:
                    info(k, v)
    else:
        warn("Defender Status", "Could not query (run as admin or Defender not present)")

    # Third‑party AV via WMI
    sub_header("Registered Antivirus Products (WMI)")
    av_products = run_powershell(
        "Get-CimInstance -Namespace root/SecurityCenter2 "
        "-ClassName AntiVirusProduct "
        "| Select-Object displayName, productState | Format-List"
    )
    if av_products:
        for line in av_products.splitlines():
            if line.strip():
                bullet(line.strip())
    else:
        bullet("No third‑party AV detected (or not available on Server SKU)")

    report.add_section("antivirus", defender)


# ──────────────────────────────────────────────
# MODULE 8 : INSTALLED SOFTWARE
# ──────────────────────────────────────────────

def audit_installed_software():
    section_header("INSTALLED SOFTWARE")

    raw = run_powershell(
        "Get-ItemProperty "
        "HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*,"
        "HKLM:\\Software\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* "
        "| Where-Object { $_.DisplayName } "
        "| Select-Object DisplayName, DisplayVersion, Publisher, InstallDate "
        "| Sort-Object DisplayName | Format-Table -AutoSize"
    )

    sw_list: list[str] = []
    if raw:
        for line in raw.splitlines():
            line_s = line.strip()
            if line_s and "----" not in line_s:
                bullet(line_s)
                sw_list.append(line_s)
    else:
        warn("Installed Software", "Could not enumerate")

    report.add_section("installed_software", {"count": len(sw_list), "list": sw_list})


# ──────────────────────────────────────────────
# MODULE 9 : RUNNING SERVICES
# ──────────────────────────────────────────────

def audit_services():
    section_header("RUNNING SERVICES AUDIT")

    raw = run_powershell(
        "Get-Service | Where-Object {$_.Status -eq 'Running'} "
        "| Select-Object Name, DisplayName, StartType "
        "| Sort-Object Name | Format-Table -AutoSize"
    )

    services: list[str] = []
    if raw:
        for line in raw.splitlines():
            line_s = line.strip()
            if line_s and "----" not in line_s:
                bullet(line_s)
                services.append(line_s)

    # Dangerous default services
    sus_services = [
        "RemoteRegistry", "TlntSvr", "SSDPSRV",
        "upnphost", "SNMP", "WinRM",
    ]
    sub_header("Potentially Risky Services Check")
    running_names_raw = run_powershell(
        "Get-Service | Where-Object {$_.Status -eq 'Running'} "
        "| Select-Object -ExpandProperty Name"
    )
    running_names = {s.strip().lower() for s in running_names_raw.splitlines()}

    found = False
    for s in sus_services:
        if s.lower() in running_names:
            finding(f"Service '{s}' is running")
            report.add_finding("WARNING", f"Risky service running: {s}")
            found = True
    if not found:
        ok("No commonly‑risky services detected running")

    report.add_section("services", {"running_count": len(services)})


# ──────────────────────────────────────────────
# MODULE 10 : SCHEDULED TASKS
# ──────────────────────────────────────────────

def audit_scheduled_tasks():
    section_header("SCHEDULED TASKS (non‑Microsoft)")

    raw = run_powershell(
        "Get-ScheduledTask | Where-Object "
        "{$_.TaskPath -notlike '\\Microsoft*'} "
        "| Select-Object TaskName, TaskPath, State "
        "| Format-Table -AutoSize"
    )

    tasks: list[str] = []
    if raw:
        for line in raw.splitlines():
            line_s = line.strip()
            if line_s and "----" not in line_s:
                bullet(line_s)
                tasks.append(line_s)
    else:
        bullet("No non‑Microsoft scheduled tasks found (or access denied)")

    report.add_section("scheduled_tasks", {"count": len(tasks), "tasks": tasks})


# ──────────────────────────────────────────────
# MODULE 11 : STARTUP PROGRAMS
# ──────────────────────────────────────────────

def audit_startup():
    section_header("STARTUP PROGRAMS")

    raw = run_powershell(
        "Get-CimInstance Win32_StartupCommand "
        "| Select-Object Name, Command, Location, User "
        "| Format-List"
    )

    if raw:
        blocks = [b.strip() for b in raw.split("\n\n") if b.strip()]
        for block in blocks:
            for line in block.splitlines():
                if line.strip():
                    bullet(line.strip())
            print()
    else:
        bullet("No startup entries found (or access denied)")

    report.add_section("startup_programs", {"raw": raw})


# ──────────────────────────────────────────────
# MODULE 12 : SHARED FOLDERS
# ──────────────────────────────────────────────

def audit_shares():
    section_header("NETWORK SHARES")

    raw = run_powershell(
        "Get-SmbShare | Select-Object Name, Path, Description "
        "| Format-Table -AutoSize"
    )

    shares: list[str] = []
    if raw:
        for line in raw.splitlines():
            line_s = line.strip()
            if line_s and "----" not in line_s:
                bullet(line_s)
                shares.append(line_s)
    else:
        raw_net = run_cmd("net share")
        if raw_net:
            for line in raw_net.splitlines():
                bullet(line.strip())
                shares.append(line.strip())

    report.add_section("shares", {"count": len(shares), "shares": shares})


# ──────────────────────────────────────────────
# MODULE 13 : WINDOWS UPDATE STATUS
# ──────────────────────────────────────────────

def audit_updates():
    section_header("WINDOWS UPDATE STATUS")

    sub_header("Last 10 Installed Updates")
    raw = run_powershell(
        "Get-HotFix | Sort-Object InstalledOn -Descending -ErrorAction SilentlyContinue "
        "| Select-Object -First 10 HotFixID, Description, InstalledOn "
        "| Format-Table -AutoSize"
    )

    if raw:
        for line in raw.splitlines():
            line_s = line.strip()
            if line_s and "----" not in line_s:
                bullet(line_s)
    else:
        warn("Updates", "Could not query hotfix history")

    # Last update date check
    last_date_raw = run_powershell(
        "(Get-HotFix | Sort-Object InstalledOn -Descending "
        "-ErrorAction SilentlyContinue "
        "| Select-Object -First 1).InstalledOn"
    )
    if last_date_raw:
        sub_header("Patch Currency")
        info("Last Patch Installed", last_date_raw)
        try:
            last_dt = datetime.datetime.strptime(
                last_date_raw.split()[0], "%m/%d/%Y"
            )
            days_ago = (datetime.datetime.now() - last_dt).days
            info("Days Since Last Patch", str(days_ago))
            if days_ago > 60:
                crit_finding(f"System has not been patched in {days_ago} days!")
                report.add_finding("CRITICAL",
                                   f"No patches installed in {days_ago} days")
            elif days_ago > 30:
                finding(f"Last patch was {days_ago} days ago")
                report.add_finding("WARNING",
                                   f"Patches are {days_ago} days old")
            else:
                ok(f"Patches are current ({days_ago} days old)")
        except Exception:
            pass

    report.add_section("updates", {"last_patch": last_date_raw})


# ──────────────────────────────────────────────
# MODULE 14 : SECURITY POLICY & AUDIT SETTINGS
# ──────────────────────────────────────────────

def audit_security_policy():
    section_header("SECURITY CONFIGURATION CHECKS")

    # --- UAC ---
    sub_header("User Account Control (UAC)")
    uac_raw = run_powershell(
        "(Get-ItemProperty "
        "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
        ").EnableLUA"
    )
    if uac_raw:
        enabled = uac_raw.strip() == "1"
        if enabled:
            ok("UAC is ENABLED")
        else:
            crit_finding("UAC is DISABLED")
            report.add_finding("CRITICAL", "UAC is disabled")
        info("EnableLUA", uac_raw.strip())

    # --- Remote Desktop ---
    sub_header("Remote Desktop (RDP)")
    rdp_raw = run_powershell(
        "(Get-ItemProperty "
        "'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server'"
        ").fDenyTSConnections"
    )
    if rdp_raw:
        rdp_on = rdp_raw.strip() == "0"
        if rdp_on:
            finding("RDP is ENABLED")
            report.add_finding("INFO", "RDP is enabled")
        else:
            ok("RDP is DISABLED")
        info("fDenyTSConnections", rdp_raw.strip())

    # NLA for RDP
    nla_raw = run_powershell(
        "(Get-ItemProperty "
        "'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server"
        "\\WinStations\\RDP-Tcp').UserAuthentication"
    )
    if nla_raw:
        nla = nla_raw.strip() == "1"
        if nla:
            ok("Network Level Authentication (NLA) is enabled")
        else:
            finding("NLA is DISABLED for RDP — weaker auth")
            report.add_finding("WARNING", "RDP NLA is disabled")

    # --- SMBv1 ---
    sub_header("SMBv1 Protocol")
    smbv1 = run_powershell(
        "(Get-SmbServerConfiguration).EnableSMB1Protocol"
    )
    if smbv1:
        if smbv1.strip().lower() == "true":
            crit_finding("SMBv1 is ENABLED — critical vulnerability risk!")
            report.add_finding("CRITICAL", "SMBv1 protocol is enabled")
        else:
            ok("SMBv1 is disabled")
        info("EnableSMB1Protocol", smbv1.strip())
    else:
        bullet("Could not determine SMBv1 status")

    # --- AutoRun ---
    sub_header("AutoRun / AutoPlay")
    autorun = run_powershell(
        "(Get-ItemProperty "
        "'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer' "
        "-ErrorAction SilentlyContinue).NoDriveTypeAutoRun"
    )
    if autorun and autorun.strip() == "255":
        ok("AutoRun is disabled for all drives")
    else:
        finding("AutoRun may not be fully disabled")
        report.add_finding("WARNING", "AutoRun not fully disabled")

    # --- Windows Script Host ---
    sub_header("Windows Script Host")
    wsh = run_powershell(
        "(Get-ItemProperty "
        "'HKLM:\\SOFTWARE\\Microsoft\\Windows Script Host\\Settings' "
        "-ErrorAction SilentlyContinue).Enabled"
    )
    if wsh and wsh.strip() == "0":
        ok("Windows Script Host is disabled")
    else:
        finding("Windows Script Host is enabled (macro/script risk)")
        report.add_finding("INFO", "Windows Script Host is enabled")

    # --- PowerShell Execution Policy ---
    sub_header("PowerShell Execution Policy")
    exec_pol = run_powershell("Get-ExecutionPolicy -List | Format-Table -AutoSize")
    if exec_pol:
        for line in exec_pol.splitlines():
            if line.strip() and "----" not in line:
                bullet(line.strip())
                if "Unrestricted" in line or "Bypass" in line:
                    scope = line.split()[0] if line.split() else ""
                    finding(f"Scope '{scope}' has permissive execution policy")
                    report.add_finding("WARNING",
                                       f"PS ExecutionPolicy permissive: {line.strip()}")

    report.add_section("security_policy", {
        "uac_enabled": uac_raw,
        "rdp_enabled": rdp_raw,
        "smbv1": smbv1,
    })


# ──────────────────────────────────────────────
# MODULE 15 : EVENT LOG HIGHLIGHTS
# ──────────────────────────────────────────────

def audit_event_logs():
    section_header("SECURITY EVENT LOG HIGHLIGHTS")

    # Failed logins (4625)
    sub_header("Failed Login Attempts (last 24h, Event 4625)")
    failed = run_powershell(
        "Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4625; "
        "StartTime=(Get-Date).AddDays(-1)} -MaxEvents 20 "
        "-ErrorAction SilentlyContinue "
        "| Select-Object TimeCreated, Message "
        "| ForEach-Object { $_.TimeCreated.ToString() + ' | ' + "
        "($_.Message -split '\\n')[0] }"
    )
    if failed:
        count = 0
        for line in failed.splitlines():
            if line.strip():
                bullet(line.strip())
                count += 1
        if count > 10:
            finding(f"{count} failed logins in 24h — possible brute force")
            report.add_finding("WARNING",
                               f"{count} failed logins in last 24 hours")
    else:
        ok("No failed logins in last 24 hours (or insufficient privileges)")

    # Account lockouts (4740)
    sub_header("Account Lockouts (last 7d, Event 4740)")
    lockouts = run_powershell(
        "Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4740; "
        "StartTime=(Get-Date).AddDays(-7)} -MaxEvents 10 "
        "-ErrorAction SilentlyContinue "
        "| Select-Object TimeCreated, Message "
        "| ForEach-Object { $_.TimeCreated.ToString() }"
    )
    if lockouts:
        for line in lockouts.splitlines():
            if line.strip():
                finding(f"Lockout at {line.strip()}")
    else:
        ok("No account lockouts in last 7 days")

    # Cleared audit logs (1102)
    sub_header("Audit Log Cleared Events (Event 1102)")
    cleared = run_powershell(
        "Get-WinEvent -FilterHashtable @{LogName='Security'; Id=1102} "
        "-MaxEvents 5 -ErrorAction SilentlyContinue "
        "| Select-Object TimeCreated "
        "| ForEach-Object { $_.TimeCreated.ToString() }"
    )
    if cleared:
        for line in cleared.splitlines():
            if line.strip():
                crit_finding(f"Audit log was CLEARED at {line.strip()}")
                report.add_finding("CRITICAL",
                                   f"Security log cleared at {line.strip()}")
    else:
        ok("No audit‑log‑cleared events found")

    report.add_section("event_logs", {
        "failed_logins": failed,
        "lockouts": lockouts,
        "log_cleared": cleared,
    })


# ──────────────────────────────────────────────
# MODULE 16 : LOCAL PRIVILEGE ESCALATION CHECKS
# ──────────────────────────────────────────────

def audit_privesc_vectors():
    section_header("PRIVILEGE ESCALATION QUICK CHECKS")

    # Unquoted service paths
    sub_header("Unquoted Service Paths")
    unquoted = run_powershell(
        "Get-CimInstance Win32_Service "
        "| Where-Object { $_.PathName -and "
        "$_.PathName -notlike '\"*' -and "
        "$_.PathName -like '* *' -and "
        "$_.PathName -notlike 'C:\\Windows*' } "
        "| Select-Object Name, PathName | Format-List"
    )
    if unquoted and unquoted.strip():
        for line in unquoted.splitlines():
            if line.strip():
                finding(line.strip())
        report.add_finding("WARNING", "Unquoted service path(s) found")
    else:
        ok("No unquoted service paths detected")

    # AlwaysInstallElevated
    sub_header("AlwaysInstallElevated Registry Key")
    aie_hklm = run_powershell(
        "(Get-ItemProperty "
        "'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\Installer' "
        "-ErrorAction SilentlyContinue).AlwaysInstallElevated"
    )
    aie_hkcu = run_powershell(
        "(Get-ItemProperty "
        "'HKCU:\\SOFTWARE\\Policies\\Microsoft\\Windows\\Installer' "
        "-ErrorAction SilentlyContinue).AlwaysInstallElevated"
    )
    if (aie_hklm and aie_hklm.strip() == "1") or \
       (aie_hkcu and aie_hkcu.strip() == "1"):
        crit_finding("AlwaysInstallElevated is SET — privesc vector!")
        report.add_finding("CRITICAL", "AlwaysInstallElevated is enabled")
    else:
        ok("AlwaysInstallElevated is not set")

    # Writable PATH directories
    sub_header("Writable PATH Directories")
    path_dirs = os.environ.get("PATH", "").split(";")
    writable_found = False
    for d in path_dirs:
        d = d.strip()
        if d and os.path.isdir(d):
            try:
                test_file = os.path.join(d, ".winrecon_write_test")
                with open(test_file, "w") as f:
                    f.write("test")
                os.remove(test_file)
                finding(f"Writable PATH directory: {d}")
                report.add_finding("WARNING", f"Writable PATH dir: {d}")
                writable_found = True
            except (PermissionError, OSError):
                pass
    if not writable_found:
        ok("No writable directories in system PATH")

    report.add_section("privesc_checks", {
        "unquoted_paths": bool(unquoted and unquoted.strip()),
        "always_install_elevated": (aie_hklm, aie_hkcu),
        "writable_path": writable_found,
    })


# ──────────────────────────────────────────────
# FINDINGS SUMMARY
# ──────────────────────────────────────────────

def print_findings_summary():
    section_header("FINDINGS SUMMARY")

    findings = report._findings
    crits    = [f for f in findings if f["severity"] == "CRITICAL"]
    warns    = [f for f in findings if f["severity"] == "WARNING"]
    infos    = [f for f in findings if f["severity"] == "INFO"]

    print()
    info("Critical", str(len(crits)))
    info("Warnings", str(len(warns)))
    info("Informational", str(len(infos)))
    print()

    if crits:
        sub_header("Critical Findings")
        for f in crits:
            crit_finding(f["message"])

    if warns:
        sub_header("Warnings")
        for f in warns:
            finding(f["message"])

    if infos:
        sub_header("Informational")
        for f in infos:
            bullet(f["message"])

    if not findings:
        ok("No significant findings — nice work!")


# ──────────────────────────────────────────────
# MAIN ENTRY POINT
# ──────────────────────────────────────────────

def main():
    enable_ansi()

    # Platform gate
    if platform.system() != "Windows":
        print(f"{C.RED}[!] WinRecon is designed for Windows systems only.{C.RESET}")
        print(f"{C.YELLOW}    Detected platform: {platform.system()}{C.RESET}")
        sys.exit(1)

    print(BANNER)

    if not is_admin():
        print(f"  {C.YELLOW}[!] Running WITHOUT administrator privileges.{C.RESET}")
        print(f"  {C.YELLOW}    Some checks will be limited. Re‑run as Admin for full audit.{C.RESET}")
    else:
        print(f"  {C.GREEN}[✓] Running with administrator privileges.{C.RESET}")

    print(f"\n  {C.DIM}Scan started: {datetime.datetime.now()}{C.RESET}")

    # ── Run all modules ──
    modules = [
        ("System Information",      audit_system_info),
        ("Users & Groups",          audit_users_groups),
        ("Password Policy",         audit_password_policy),
        ("Network Configuration",   audit_network_config),
        ("Open Ports",              audit_open_ports),
        ("Firewall",                audit_firewall),
        ("Antivirus / Defender",    audit_defender),
        ("Installed Software",      audit_installed_software),
        ("Running Services",        audit_services),
        ("Scheduled Tasks",         audit_scheduled_tasks),
        ("Startup Programs",        audit_startup),
        ("Network Shares",          audit_shares),
        ("Windows Updates",         audit_updates),
        ("Security Policy",         audit_security_policy),
        ("Event Logs",              audit_event_logs),
        ("Privilege Escalation",    audit_privesc_vectors),
    ]

    for name, func in modules:
        try:
            func()
        except Exception as e:
            print(f"\n  {C.RED}[ERROR] Module '{name}' failed: {e}{C.RESET}")

    # ── Summary ──
    print_findings_summary()

    # ── Export ──
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    hostname  = platform.node()
    json_file = f"winrecon_{hostname}_{timestamp}.json"

    section_header("EXPORT")
    try:
        report.export_json(json_file)
        ok(f"Full report saved to {json_file}")
    except Exception as e:
        warn("Export", f"Failed to write JSON: {e}")

    print(f"\n  {C.DIM}Scan completed: {datetime.datetime.now()}{C.RESET}")
    print(DIVIDER)
    print(f"  {C.CYAN}Thank you for using WinRecon — stay secure.{C.RESET}")
    print(DIVIDER)
    print()


if __name__ == "__main__":
    main()